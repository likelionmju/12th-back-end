import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LotteryChecker {
    private static List<int[]> lotteryResult = new ArrayList<>();
    private static List<Integer> lotteryBonusResult = new ArrayList<>();

    public static void main(String[] args) throws LotteryFileread.InvalidFileFormatException, FileNotFoundException {

        List<Integer> winNum = LotteryFileread.getWinningNumbers();
        int bonusNum = LotteryFileread.getBonusNumber();
        List<int[]> userNumbersList = LotteryRandom.getUserNumbersList();

        lotteryBonusResult.addAll(winNum);
        lotteryBonusResult.add(bonusNum);

        Collections.sort(lotteryBonusResult);
        Collections.sort(winNum);

        for (int[] array : userNumbersList) {
            Arrays.sort(array);
        }


        int[] matchCountArray = new int[userNumbersList.size()];

        for (int i = 0; i < userNumbersList.size(); i++) {
            int[] array = userNumbersList.get(i);
            for (int number : array) {
                if (winNum.contains(number)) {
                    matchCountArray[i]++;
                }
            }
        }

        int[] bonusMatchCountArray = new int[userNumbersList.size()];

        for (int i = 0; i < userNumbersList.size(); i++) {
            int[] array = userNumbersList.get(i);
            for (int number : array) {
                if (lotteryBonusResult.contains(number)) {
                    bonusMatchCountArray[i]++;

                }
            }
        }
        for (int i = 0; i < matchCountArray.length; i++) {
            int[] result = new int[]{matchCountArray[i]};
            lotteryResult.add(result);
        }
        for (int i = 0; i < bonusMatchCountArray.length; i++) { // 보너스 넘버
            int[] result = new int[]{bonusMatchCountArray[i]};
            lotteryResult.add(3, result);
        }

    }
    public static List<int[]> getLotteryResult(){
        return lotteryResult;
    }
    public static List<Integer> getLotteryBonusResult(){
        return lotteryBonusResult;
    }
}


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LotteryFileread {
    public static void main(String[] args){
        try {
            List<Integer> winningNumbers = getWinningNumbers();
            int bonusNumber = getBonusNumber();

            System.out.println("당첨번호: " + winningNumbers);
            System.out.println("보너스 번호: " + bonusNumber);
        } catch (FileNotFoundException e) {
            System.err.println("파일을 찾을 수 없습니다: " + e.getMessage());
            e.printStackTrace();
        } catch (InvalidFileFormatException e) {
            System.err.println("유효하지 않은 파일 형식입니다: " + e.getMessage());
        }
    }

    public static List<Integer> getWinningNumbers() throws FileNotFoundException, InvalidFileFormatException {
        String filePath = "C:\\Users\\82109\\OneDrive\\바탕 화면\\LotteryNumber.txt";
        List<Integer> lotteryNumbers = readLotteryNumbers(filePath);
        return lotteryNumbers.subList(0, 6);
    }

    public static int getBonusNumber() throws FileNotFoundException, InvalidFileFormatException {
        String filePath = "C:\\Users\\82109\\OneDrive\\바탕 화면\\LotteryNumber.txt";
        List<Integer> lotteryNumbers = readLotteryNumbers(filePath);
        return lotteryNumbers.get(6);
    }

    public static List<Integer> readLotteryNumbers(String filePath) throws FileNotFoundException, InvalidFileFormatException {
        List<Integer> numbers = new ArrayList<>();
        Pattern numberPattern = Pattern.compile("\\d+");

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                Matcher matcher = numberPattern.matcher(line);
                while (matcher.find()) {
                    int number = Integer.parseInt(matcher.group());
                    if (number < 1 || number > 45) {
                        throw new InvalidFileFormatException("파일에 유효한 숫자가 아닌 수가 포함되어 있습니다: " + number);
                    }
                    numbers.add(number);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (numbers.size() < 7) {
            throw new InvalidFileFormatException("파일에 충분한 숫자가 포함되어 있지 않습니다.");
        }

        return numbers;
    }

    public static class InvalidFileFormatException extends Exception {
        public InvalidFileFormatException(String message) {
            super(message);
        }
    }
}

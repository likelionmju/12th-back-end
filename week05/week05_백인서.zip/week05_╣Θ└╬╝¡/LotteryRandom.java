import org.w3c.dom.ls.LSOutput;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class LotteryRandom {
    private static List<int[]> userNumbersList = new ArrayList<>();

    public static void makeRandom() {
        int HowMany = LotteryInput.HowMany;

        for (int j = 0; j < HowMany; j++) {
            int size = 6;
            int[] randomArray = new int[size];
            Random random = new Random();

            for (int i = 0; i < size; i++) {
                int randomNumber;
                boolean isDuplicate;
                do {
                    randomNumber = random.nextInt(45) + 1;
                    isDuplicate = false;

                    for (int k = 0; k < i; k++) {
                        if (randomNumber == randomArray[k]) {
                            isDuplicate = true;
                            break;
                        }
                    }
                } while (isDuplicate);
                randomArray[i] = randomNumber;
            }
            userNumbersList.add(randomArray);
        }
    }
    public static List<int[]> getUserNumbersList() {
        return userNumbersList;
    }
}

import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) throws LotteryFileread.InvalidFileFormatException, FileNotFoundException {

        LotteryInput.inputPrice();
        LotteryRandom.makeRandom();

        List<int[]> userNumbersList = LotteryRandom.getUserNumbersList();

        for (int[] array : userNumbersList) {
            System.out.println(Arrays.toString(array));
        }
        System.out.println();

        LotteryFileread.main(args);

        System.out.println();

        LotteryChecker.main(args);
        LotteryResult.main(args);
    }
}

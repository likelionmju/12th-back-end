package LottoProject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileRead {
    BufferedReader reader;
    // 당첨번호 넣을 배열
    private int[] ansnum = new int[7];

    // ,로 구분되어있는 lotto.txt 파일 읽기
    public FileRead() {
        try {
            reader = new BufferedReader(new FileReader("C:\\Users\\강예린\\Documents\\lotto.txt"));
            String line = reader.readLine();
            if (line != null) {
                String[] s = line.split(",");
                for (int i = 0; i < 7; i++) {
                    ansnum[i] = Integer.parseInt(s[i]);
                }
            }
            reader.close();  // 리소스를 적절히 해제합니다.
        } catch (IOException e) {
            System.out.println("파일이 존재하지 않습니다.");
        }
    }

    public int[] getAnsnum() {
        return ansnum;
    }
}

package LottoProject;

public class Main {

    public static void main(String[] args) {
        // 돈을 지불하여 구매
        Purchase p= new Purchase();
        // 가격에 맞는만큼 로또 발행
        Ticket t= new Ticket(p);
        // 그만큼의 로또번호 가져옴
        Number n= new Number(t);
        // 당첨번호와 로또번호 비교
        Matching m= new Matching(n);
        // 수익률
        Profit pr= new Profit(p,m);
    }
}

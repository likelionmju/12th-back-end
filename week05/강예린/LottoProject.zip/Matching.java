package LottoProject;

import java.util.LinkedList;

public class Matching {
    FileRead fr= new FileRead();

    // 1등 2등 3등 4등 5등이 몇개 당첨되었는지 reward 배열에 저장
    private int[] reward = {0,0,0,0,0};

    // 등수별 보상액
    int [] price= { 2000000000, 30000000,1500000, 50000, 5000};
    //총 상금
    private int total=0;

    public Matching(Number num){
        matchedNum(num);
        printPrice();
    }

    public int[] getPrice() {
        return price;
    }

    public int getTotal() {
        return total;
    }

    // 6번째 숫자까지 확인 후 5개 맞으면 마지막 보너스 넘버도 확인
    public void matchedNum(Number num) {
        LinkedList<int[]> lotto= num.getLotto();
        while (!lotto.isEmpty()) { //장 수 만큼 비교
            int arr[] = lotto.remove();
            int cnt=0;
            for (int j=0; j< arr.length; j++){ //기본번호에서 몇개가 같은지
                for (int k=0; k<arr.length; k++){
                    if (arr[j]== fr.getAnsnum()[k]) {
                        cnt++;
                        break;
                    }
                }
            }
            switch (cnt){
                case 6:
                    reward[0]++;
                    break;
                case 5:
                    for(int i=0;i<arr.length; i++){
                       if(arr[i]==fr.getAnsnum()[6]) reward[1]++;
                    }
                    reward[2]++;
                    break;
                case 4:
                    reward[3]++;
                    break;
                case 3:
                    reward[4]++;
                    break;
            }
        }
    }
    // 당첨번호랑 결과
    public void printPrice(){
        System.out.print("당첨 번호는: ");
        for (int i=0; i<fr.getAnsnum().length; i++) System.out.print(fr.getAnsnum()[i]+" ");
        System.out.println();
        for (int i=0; i<reward.length; i++){
            System.out.println((i+1)+"등 ("+getPrice()[i]+"): "+reward[i]+"개");
            total+= price[i]*reward[i];
        }
        System.out.println("총 "+getTotal()+"원 입니다.");
    }
}

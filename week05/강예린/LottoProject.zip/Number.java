package LottoProject;

import java.lang.annotation.Target;
import java.util.Iterator;
import java.util.LinkedList;

public class Number{
    //여러 장의 로또들을 넣을 연결리스트
    private LinkedList<int[]> lotto;
    public Number(Ticket t){
        lotto= new LinkedList<int[]>();
        randomNum(t);
        printNum(t);
    }

    public LinkedList<int[]> getLotto() {
        return lotto;
    }

    // 7개의 랜덤숫자 만들기
    public void randomNum(Ticket t){
        for (int i=0; i< t.getTicketCount(); i++){
            int [] arr= new int[6];
            //1~45 랜덤 숫자 7개 만들기
            for(int j=0; j< arr.length; j++) {
                while (true) {
                    Boolean unique= true;
                    int ran = (int) (Math.random() * 45 + 1);
                    for (int k = 0; k < j; k++) { // 중복 없기 위해 이전 번호들과 비교
                        if (arr[k] == ran) {
                            unique= false;
                            break;}
                    }
                    if (unique){
                        arr[j]= ran;
                        break;
                    }
                }
            }
                lotto.add(arr);
            }
    }
    // 장 수와 번호들 출력
    public void printNum(Ticket t) {
        Iterator<int[]> it= getLotto().iterator();
        System.out.println( t.getTicketCount()+"장 구매하셨습니다.");
        while(it.hasNext()){
            int arr[] = it.next();
            for (int i=0; i<arr.length; i++) System.out.print(arr[i]+" ");
            System.out.println();
        }
    }

}

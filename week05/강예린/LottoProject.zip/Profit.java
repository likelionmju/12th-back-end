package LottoProject;

public class Profit {
    private double ratio;

    public Profit(Purchase p, Matching m){
        if(p.getPayment()==0) ratio=0; // 수익이없으면 0
        else ratio= (p.getPayment()-m.getTotal())/(double)p.getPayment()*100;
        printProfit();
    }
    public void printProfit(){
        System.out.println("수익률은 "+getRatio()+"%");
    }
    public double getRatio() {
        return ratio;
    }
}

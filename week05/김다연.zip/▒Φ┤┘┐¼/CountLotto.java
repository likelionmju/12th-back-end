package week05lotto;

public class CountLotto {
    private  int fifth=0,fourth = 0,third = 0,second = 0,first = 0;

    public int getFifth() {
        return fifth;
    }
    public void setFifth(int fifth) {
        this.fifth = fifth;
    }
    public int getFourth() {
        return fourth;
    }

    public void setFourth(int fourth) {
        this.fourth = fourth;
    }

    public int getThird() {
        return third;
    }

    public void setThird(int third) {
        this.third = third;
    }

    public int getSecond() {
        return second;
    }

    public void setSecond(int second) {
        this.second = second;
    }

    public int getFirst() {
        return first;
    }

    public void setFirst(int first){
        this.first =  first;
    }


}

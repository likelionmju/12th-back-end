package lotto;

public abstract class Lotto {
    protected int[] lottoNumbers;
    public Lotto() {
        this.lottoNumbers = new int[6];
    }

    public int[] getLottoNumber(){
        return this.lottoNumbers;
    }
    abstract public void showLottoNumbers();
}

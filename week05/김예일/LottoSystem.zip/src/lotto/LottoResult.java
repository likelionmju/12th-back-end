package lotto;

public class LottoResult {
    private final int generatedAmount;
    private final PlayerLotto[] generatedLottoArr;
    private final int[] winningNumbers;
    private final int bonusNumber;
    private final int[] prizeArr;
    private final int[] prizeCountArr;

    public LottoResult(LottoGenerator lottoGenerator, WinningLotto winningLotto) {
        this.generatedAmount = lottoGenerator.getGeneratedAmount();
        this.generatedLottoArr = lottoGenerator.getGeneratedLottoArr();
        this.winningNumbers = winningLotto.getLottoNumber();
        this.bonusNumber = winningLotto.getBonusNumber();
        this.prizeArr = new int[]{2000000000, 30000000, 1500000, 50000, 5000, 0};
        this.prizeCountArr = new int[6];

        checkLottoResult();
    }

    // 로또 결과 출력
    public void showLottoResult() {
        for (int i = 0; i < prizeCountArr.length - 1; i++) {
            System.out.printf("%d등 당첨: %d개 \n", i + 1, prizeCountArr[i]);
        }
        calculateProfit();  // 수익률 계산 및 출력
    }

    // 로또 결과 계산
    private void checkLottoResult(){
        for (PlayerLotto generatedLotto : generatedLottoArr) {
            int[] lottoNumbers = generatedLotto.getLottoNumber();               // 추첨 번호 가져오기
            int count = countMatchedNumbers(lottoNumbers, winningNumbers);      // 당첨 번호와 몇개 일치하는지 계산
            boolean isMatchedBonus = checkMatchedBonus(lottoNumbers, bonusNumber);    // 보너스 일치 여부
            prizeCountArr[getPrize(count, isMatchedBonus)]++;       // 등수 계산 후 당첨 횟수 최신화
        }
    }

    // 당첨 번호 몇개 맞았는지 계산
    private int countMatchedNumbers(int[] playerNumbers, int[] winningNumbers) {
        int count = 0;
        for (int playerNumber : playerNumbers) {
            for (int winningNumber : winningNumbers) {
                if (playerNumber == winningNumber) {
                    count++;
                    break;
                }
            }
        }
        return count;
    }

    // 보너스 번호 맞았는지 체크
    private boolean checkMatchedBonus(int[] playerNumbers, int bonusNumber) {
        for (int playerNumber : playerNumbers) {
            if (playerNumber == bonusNumber)
                return true;
        }
        return false;
    }

    // 등수 계산 후 해당 등수 인덱스 반환
    private int getPrize(int count, boolean isMatchedBonus) {
        switch (count) {
            case 6:
                return 0;
            case 5:
                if (isMatchedBonus) return 1;
                else return 2;
            case 4:
                return 3;
            case 3:
                return 4;
            default:
                return 5;
        }
    }

    // 수익률 계산
    private void calculateProfit() {
        int totalPrize = calculateTotalPrize();
        System.out.println("총 수익금: " + generatedAmount);
        System.out.println("총 당첨금: " + totalPrize);

        double rate = ((double) (generatedAmount - totalPrize) / generatedAmount) * 100;
        System.out.printf("총 수익률: %.1f%%", rate);
    }

    // 총 당첨금 계산
    private int calculateTotalPrize() {
        int sum = 0;
        for (int i = 0; i < prizeCountArr.length; i++)
            sum += prizeArr[i] * prizeCountArr[i];

        return sum;
    }
}

package lotto;

public class Main {
    public static void main(String[] args) {
        // 로또 구매
        LottoPurchase lottoPurchase = new LottoPurchase();

        // 추첨 로또 발행
        LottoGenerator lottoGenerator = new LottoGenerator(lottoPurchase.getAmount());
        lottoGenerator.showGeneratedLottoNum();

        // 당첨 로또 가져오기
        WinningLotto winningLotto = new WinningLotto();
        winningLotto.showLottoNumbers();

        // 로또 결과
        LottoResult lottoResult = new LottoResult(lottoGenerator, winningLotto);
        lottoResult.showLottoResult();
    }
}
import java.util.ArrayList;

public class Lotto_Raffle extends Main{ //로또 발행하는 클래스
    private static int Lotto_C; // Main 클래스의 Lotto_C 변수를 대체하는 변수
    int win_num_cnt = 0;
    int bonus_win_num = 0;
    int win1 = 0;
    int win2 = 0;
    int win3 = 0;
    int win4 = 0;
    int win5 = 0;
    int win_money = 0;

    public Lotto_Raffle() {

    }

    public Lotto_Raffle(int lottoC, int[] win_number, int bonusnum) {
        super();
    }

    public int Lotto_Raffle(int Lotto_C, int[] win_number, int bonusnum) {
        Lotto_Raffle.Lotto_C = Lotto_C; //Main 클래스의 Lotto_C 변수 가져오기
        for(int i=0; i<Lotto_C; i++) { //만들어져야하는 로또만큼 반복
            ArrayList<Integer> numbers = new ArrayList<Integer>(); //arraylist 선언

            for (int j = 0; j < 6; j++) { //로또 숫자 6개 만들기
                int RN = Random_L.Random_N(); //RN에 랜덤 수 받기

                if (!numbers.contains(RN)){ //중복되는 숫자 걸러주기
                    numbers.add(RN);
                }
                System.out.print(RN + " ");

                for(int k=0; k<6; k++){ //당첨 개수 확인
                    if(win_number[k] == RN){
                        win_num_cnt ++;
                    }
                }
                if (RN == bonusnum){ //보너스 번호 겹치는지 확인
                    bonus_win_num ++;
                }

            }
            System.out.print("\n");
            //-------------------------------등수 체크---
            if(win_num_cnt == 6){
                win1++;
                win_money += 2000000000;
            }else if(win_num_cnt==5 && bonus_win_num==1){
                win2++;
                win_money += 30000000;
            }else if(win_num_cnt==5){
                win3++;
                win_money += 1500000;
            }else if(win_num_cnt==4){
                win4++;
                win_money += 50000;
            }else if(win_num_cnt==3){
                win5++;
                win_money += 5000;
            }
            //등수 확인 변수들 초기화
            win_num_cnt = 0;
            bonus_win_num = 0;
        }

        System.out.println("1등: " + win1 + "명");
        System.out.println("2등: " + win2 + "명");
        System.out.println("3등: " + win3 + "명");
        System.out.println("4등: " + win4 + "명");
        System.out.println("5등: " + win5 + "명");

        return win_money;
    }



}

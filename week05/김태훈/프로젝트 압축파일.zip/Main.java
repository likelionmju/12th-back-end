import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        //당첨번호 받기
        Scanner scf = new Scanner(new File("./src/Winning_Number.txt"));
        int[] win_number = new int[7];
        int flag=0;
        int bonusnum = 0;
        while(scf.hasNextInt()){ //txt파일 뒤에 수가 없을 때까지 반복해서 읽기
            if(flag==6){ //보너스 번호 따로 받기
                bonusnum = scf.nextInt();
            } else { //당첨 번호 6개 받아서 저장
                win_number[flag] = scf.nextInt();
                flag++;
            }
        }


        Scanner sc = new Scanner(System.in);
        int total_M = 0; //받은 총 금액
        int Lotto_C = 0; //로또 개수
        boolean Check_total_M = false; //1000원 단위일 때를 구분하기 위한 변수

        while (!Check_total_M) { //1000원 단위임을 확인하는 while문
            System.out.print("로또 구매 금액을 입력해주세요: ");
            total_M = sc.nextInt(); // 금액 입력받기
            if (total_M % 1000 != 0) { // 로또 금액 1000원 단위로만 받기
                System.out.println("로또는 1000원 단위로만 구매 가능합니다.");
            } else {
                Check_total_M = true; //1000원 단위이면 while문 나오기
            }
        }

        Lotto_C = total_M / 1000; //총 로또 개수 체크
        Lotto_Raffle lotto_raffle = new Lotto_Raffle();
        int win_money = lotto_raffle.Lotto_Raffle(Lotto_C, win_number, bonusnum);//로또 발행
        System.out.println("총 로또 개수: " + Lotto_C + "개"); //로또 개수 확인

        float rate =  Rate.rate(total_M, win_money); //수익률 계산
        System.out.println("수익률: " + String.format("%.2f", rate) + "%"); //출력
    }

}
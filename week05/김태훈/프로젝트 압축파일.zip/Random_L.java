import java.util.Random;

public class Random_L extends Lotto_Raffle{
    
    public Random_L(int lottoC, int[] a, int bonusnum) {
        super(lottoC, a, bonusnum);
    }

    public static int Random_N(){
        Random random = new Random();

        int random_Number = random.nextInt(45) + 1; // 1부터 45 사이의 랜덤한 수 만들기
        return random_Number; //만든 수 리턴
    }
}

public class Rate {
    public static float rate(int total_M, int win_money) {
        int profit = win_money - total_M; //순이익
        float rate = 0;

        if(win_money > total_M){ //수익률이 +일 때
            rate = ((float)profit/total_M)*100;
        }else if(win_money==0){
            rate = (float)profit / 10 ;
        }else{ //수익률이 -일 때
            rate = ((float)total_M/profit)*100;
        }
        return rate;
    }
}

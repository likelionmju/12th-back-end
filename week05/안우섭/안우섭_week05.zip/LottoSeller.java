import java.util.List;

// 로또 판매원 클래스
class LottoSeller {
  private LottoTicketIssuer issuer = new LottoTicketIssuer(); // 로또 발행기 생성

  public List<LottoTicket> provideTickets(int purchaseAmount) { // 로또 구임 개수만큼 티켓 출력
    int numberOfTickets = calculateTickets(purchaseAmount); // 티켓 개수 계산 후
    return issuer.issueTickets(numberOfTickets); // 발행기에 개수 전해주기
  }

  private int calculateTickets(int purchaseAmount) { // 티켓 개수 계산 메소드
    return purchaseAmount / 1000;
  }
}
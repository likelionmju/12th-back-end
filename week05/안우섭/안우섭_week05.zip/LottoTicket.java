import java.util.Set;

// 로또 티켓 클래스
class LottoTicket {
  private Set<Integer> numbers; //Set<Integer> 컬렉션, 중복된 번호를 사용하지 않기 위해

  public LottoTicket(Set<Integer> numbers) { // 생성자
    this.numbers = numbers;
  }

  public Set<Integer> getNumbers() {  //getter
    return numbers;
  }
}
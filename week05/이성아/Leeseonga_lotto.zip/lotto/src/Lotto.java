import java.util.*;
import java.io.FileReader;
import java.io.IOException;
import java.util.stream.Collectors;

public class Lotto {
    private int money;  // 사용자가 지불한 금액
    private int[][] lottoNums;  // 구매한 로또 번호들을 저장하는 배열
    private int tickets;  // 구매한 로또 티켓의 수
    private List<List<Integer>> lottoNumsToList;  // 로또 번호들을 리스트 형태로 저장
    private List<Integer> winningNums;  // 정규 당첨 번호
    private int bonusNum;  // 보너스 번호
    private int reward;  // 당첨금
    private int first, second, third, fourth, fifth;  // 당첨된 각 등수의 수

    public static void main(String[] args) {
        int money = inputMoney();  // 사용자로부터 금액 입력받기
        Lotto lotto = new Lotto(money);  // 로또 객체 생성
        lotto.compareTickets();  // 당첨 번호와 비교
        lotto.incomeRate();  // 수익률 계산
    }

    static int inputMoney() {
        Scanner scn = new Scanner(System.in);
        int money;  // 입력받을 금액
        while (true) {
            System.out.println(">> 로또는 개당 1000원입니다. 구매할 로또 금액을 입력하시오.");
            money = scn.nextInt();
            if (money % 1000 == 0) {  // 1000원 단위로만 구매 가능
                break;
            } else {
                System.out.println(">> 로또는 1000원 단위로 구매가 가능합니다. 구매할 로또 금액을 다시 입력해주세요.");
            }
        }
        return money;  // 입력받은 금액 반환
    }

    public Lotto(int money) {
        this.tickets = money / 1000;  // 로또 티켓은 각 1000원이므로 금액에 따라 티켓 수 계산
        this.lottoNums = new int[tickets][6];  // 티켓 수만큼 로또 번호 배열 초기화
        System.out.println("\n로또 번호를 생성합니다.");

        // 로또 번호 생성
        for (int ticket = 0; ticket < tickets; ticket++) {
            List<Integer> nums = new ArrayList<>();
            for (int i = 0; i < 6; i++) {
                int num;
                do {
                    num = (int) (Math.random() * 45) + 1;
                } while (nums.contains(num));  // 이미 생성된 번호가 아닐 때까지 반복
                nums.add(num); // 중복 확인 후 생성된 번호 추가
                lottoNums[ticket][i] = num; // 배열에도 추가
            }
        }

        // 생성된 로또 번호 출력
        for (int i = 0; i < lottoNums.length; i++) {
            for (int j = 0; j < lottoNums[i].length; j++) {
                System.out.print(lottoNums[i][j] + " ");
            }
            System.out.println();
        }

        // 로또 번호 배열을 리스트로 변환 : 배열로부터 스트림 생성
        // 각 내부 배열 l에 대해 스트림을 생성, 배열의 원소를 박싱하여 Integer 객체로 만든 다음,
        // 맵을 이용하여 각 배열을 리스트로 변환, 콜렉트를 이용해 이를 리스트로 수집
        this.lottoNumsToList = Arrays.stream(lottoNums)
                .map(l -> Arrays.stream(l).boxed().collect(Collectors.toList()))
                .collect(Collectors.toList());

        // 당첨 번호와 보너스 번호 가져오기
        WinningNums winningNumsResult = getWinningNums();
        this.winningNums = winningNumsResult.getRegularNums();
        this.bonusNum = winningNumsResult.getBonusNum();
    }

    private void compareTickets() {
        System.out.println("\n>> 당첨 번호와 구매한 로또 번호를 비교합니다.");

        int ticketCount = 1;  // 티켓 카운트
        for (List<Integer> ticket : lottoNumsToList) {
            int matchCount = 0;  // 일치하는 번호 개수
            for (int i = 0; i < winningNums.size(); i++) {
                if (ticket.get(i).equals(winningNums.get(i))) {
                    matchCount++;
                }
            }

            System.out.println();
            System.out.println(">> " + ticketCount + "번째 구매한 로또가 " + matchCount + "개 번호가 일치합니다.");
            if (matchCount == 6) {
                reward += 2000000000; // 1등
                first++;
            } else if (matchCount == 5) {
                if (ticket.contains(bonusNum)) {  // 보너스 번호 체크
                    reward += 30000000; // 2등
                    second++;
                } else {
                    reward += 1500000; // 3등
                    third++;
                }
            } else if (matchCount == 4) {
                reward += 50000; // 4등
                fourth++;
            } else if (matchCount == 3) {
                reward += 5000; // 5등
                fifth++;
            }
            ticketCount++;
        }
        System.out.println("\n[ 구매한 로또 당첨 결과 확인 ]");
        System.out.println("- 1등 : " + first + "개");
        System.out.println("- 2등 : " + second + "개");
        System.out.println("- 3등 : " + third + "개");
        System.out.println("- 4등 : " + fourth + "개");
        System.out.println("- 5등 : " + fifth + "개");
        System.out.println(">> 총 당첨금은 " + reward + "원 입니다.\n");
    }

    private void incomeRate() {
        money = tickets * 1000;  // 총 사용 금액 계산
        double rate = 0;  // 수익률 초기화
        if (reward > money) {
            rate = (double) (reward - money) / money * 100; // 당첨금이 사용한 금액보다 많은 경우
        } else if (reward < money) {
            rate = (double) (reward - money) / money * 100; // 당첨금이 사용한 금액보다 적은 경우
        } else {
            rate = 0;
        }
        System.out.println(">> 수익률은 " + String.format("%.2f", rate) + "% 입니다.");
    }

    public static class WinningNums {
        private List<Integer> regularNums;  // 정규 당첨 번호
        private int bonusNum;  // 보너스 번호

        public WinningNums(List<Integer> regularNums, int bonusNum) {
            this.regularNums = regularNums;
            this.bonusNum = bonusNum;
        }

        public List<Integer> getRegularNums() {
            return regularNums;  // 정규 당첨 번호 반환
        }

        public int getBonusNum() {
            return bonusNum;  // 보너스 번호 반환
        }
    }

    public static WinningNums getWinningNums() {
        List<Integer> regularNums = new ArrayList<>();
        int bonusNum = 0;  // 보너스 번호 초기화
        try (Scanner scn = new Scanner(new FileReader("/Users/leeseonga/IdeaProjects/lotto/src/winning"))) {
            while (scn.hasNextInt()) {
                if (regularNums.size() < 6) {
                    regularNums.add(scn.nextInt());
                }
            }
            bonusNum = regularNums.remove(5);  // 마지막 번호를 보너스 번호로 지정하고 리스트에서 제거
        } catch (IOException e) {
            e.printStackTrace();
            return null;  // 예외 발생 시 null 반환
        }
        return new WinningNums(regularNums, bonusNum);  // 당첨 번호 객체 반환
    }
}
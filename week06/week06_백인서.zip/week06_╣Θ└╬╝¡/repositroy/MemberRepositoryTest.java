package repositroy;

import hello.hellospring.domain.Member;
import hello.hellospring.repository.MemberRepositroy;
import org.junit.jupiter.api.Test;

public class MemberRepositoryTest {
    MemberRepositroy repositroy = new MemberRepositroy();

    @Test
    public void save(){
        Member member = new Member();
        member.setName("spring");

        repositroy.save(member);

        Member result = repositroy.findById(member.getId()).get();
    }
}
